﻿(function () { // Angular encourages module pattern, good!
    var app = angular.module('myApp', []),
        uri = 'https://localhost:44350/api/Notification';

    errorMessage = function (data, status) {
        return 'Error: ' + status +
            (data.Message !== undefined ? (' ' + data.Message) : '');
    },

        app.controller('chatCtrl', ['$http', '$scope', '$window', '$location', function ($http, $scope, $window, $location) {

            $scope.isMessage = false;
            $scope.isNotification = false;
            $scope.inAppNotifications = [];
            $scope.isEnd = false;
            $scope.customerIdSubscribed = 0;
            $scope.messageCount = 0;
            $scope.readCount = 0;
            var searchObject = $location.search()
            $scope.customerIdSubscribed = searchObject.userid;
            $scope.messages = [];
            $scope.customerId = '1';
            $scope.goHome = function () {
                $scope.isMessage = false;
            }
            $scope.goMessages = function () {
                $scope.isMessage = true;
                $scope.readCount = $scope.messages.length;
                $scope.messageCount = 0;
            }
            $scope.showNotifications = function () {
                $scope.isNotification = !$scope.isNotification;
                if (!$scope.isNotification)
                $scope.inAppNotifications = [];
                $scope.readCount = $scope.messages.length;
                $scope.messageCount = 0;
            }
            $scope.getAllFromCustomer = function () {
                if ($scope.customerId.length == 0) return;
                $http.get(uri + '/GetUsers')
                    .success(function (data, status) {

                        $scope.messages = data; // show current users
                        //$scope.messageCount = $scope.messages.length;
                        if ($scope.customerIdSubscribed &&
                            $scope.customerIdSubscribed.length > 0 &&
                            $scope.customerIdSubscribed !== $scope.customerId) {
                            // unsubscribe to stope to get notifications for old customer
                            // hub.server.unsubscribe($scope.customerIdSubscribed);
                        }
                        // subscribe to start to get notifications for new customer
                        //hub.server.subscribe('1');

                    })
                    .error(function (data, status) {
                        //$scope.users = [];
                        $scope.errorToSearch = errorMessage(data, status);
                    })
            };


            $.connection.hub.url = 'https://localhost:44350//signalr';
            var hub = $.connection.ChatHub; // create a proxy to signalr hub on web server
            if (hub == undefined) {
                $scope.getAllFromCustomer();
                return;
            }

            if (hub && hub.connection && hub.connection.state === 4) {
                //Start the connection.
                $.connection.hub.start().done(function () {
                    
                    //$scope.customerIdSubscribed = $window.localStorage.getItem('userid');
                    hub.server.subscribe($scope.customerIdSubscribed)
                        .done(function () {
                            $scope.getAllFromCustomer();
                        })
                });
            }
            else if (hub && hub.connection && hub.connection.state !== 4) {
                hub.server.subscribe($scope.customerIdSubscribed)
                    .done(function () {
                        $scope.getAllFromCustomer();
                    });
            }



            $scope.postOne = function () {

                $http.post(uri, {
                    Userid: $scope.customerIdSubscribed,
                    Message1: $scope.descToAdd
                })
                    .success(function (data, status) {
                        $scope.errorToAdd = null;
                        $scope.descToAdd = null;
                    })
                    .error(function (data, status) {
                        $scope.errorToAdd = errorMessage(data, status);
                    })
            };
            jQuery(function ($) {
                $('#msgdiv').on('scroll', function () {
                    
                    if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight-20) {
                        $scope.isEnd = true;
                        $scope.inAppNotifications = [];
                        $scope.readCount = $scope.messages.length;
                        $scope.messageCount = 0;
                    }
                    else {
                        $scope.isEnd = false;
                    }

                    $scope.$apply();
                })
            });
            $scope.putOne = function () {
                $http.put(uri + '/' + $scope.idToUpdate, {
                    UserId: $scope.idToUpdate,
                    UserName: $scope.descToUpdate
                })
                    .success(function (data, status) {
                        $scope.errorToUpdate = null;
                        $scope.idToUpdate = null;
                        $scope.descToUpdate = null;
                    })
                    .error(function (data, status) {
                        $scope.errorToUpdate = errorMessage(data, status);
                    })
            };
            $scope.deleteOne = function (item) {
                $http.delete(uri + '/' + item.UserId)
                    .success(function (data, status) {
                        $scope.errorToDelete = null;
                    })
                    .error(function (data, status) {
                        $scope.errorToDelete = errorMessage(data, status);
                    })
            };
            $scope.editIt = function (item) {
                $scope.idToUpdate = item.UserId;
                $scope.descToUpdate = item.UserName;
            };
            $scope.toShow = function () { return $scope.messages && $scope.messages.length > 0; };

            // at initial page load
            $scope.orderProp = 'UserId';

            // signalr client functions
            hub.client.addItem = function (item) {
                
                $scope.messages.push(item);
                if (item.UserId != $scope.customerIdSubscribed) {
                    $scope.inAppNotifications.push(item);
                    $scope.messageCount = $scope.inAppNotifications.length;
                }

                //if (!$scope.isMessage || !$scope.isEnd)
                //    $scope.messageCount = $scope.messages.length - $scope.readCount;
                //else
                //    $scope.readCount = $scope.messages.length;
                $scope.$apply(); // this is outside of angularjs, so need to apply
            }
            hub.client.deleteItem = function (item) {
                var array = $scope.messages;
                for (var i = array.length - 1; i >= 0; i--) {
                    if (array[i].UserId === item.UserId) {
                        array.splice(i, 1);
                        $scope.$apply();
                    }
                }
            }
            hub.client.updateItem = function (item) {
                var array = $scope.messages;
                for (var i = array.length - 1; i >= 0; i--) {
                    if (array[i].UserId === item.UserId) {
                        array[i].UserName = item.UserName;
                        $scope.$apply();
                    }
                }
            }



            $scope.$on("notification", function (event, args) {
                $scope.getAllFromCustomer();
            });
        }]);
})();
