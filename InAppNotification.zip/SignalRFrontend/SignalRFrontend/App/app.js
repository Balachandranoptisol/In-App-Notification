﻿(function () { // Angular encourages module pattern, good!
    var app = angular.module('myApp', []),
        uri = 'https://localhost:44350/api/Account';
        errorMessage = function (data, status) {
            return 'Error: ' + status +
                (data.Message !== undefined ? (' ' + data.Message) : '');
        },
            app.controller('myCtrl', ['$http', '$scope', '$window', function ($http, $scope, $window) {
        $scope.users = [];
        $scope.customerId = '1';
        $scope.customerIdSubscribed;
        $scope.getAllFromCustomer = function () {
            if ($scope.customerId.length == 0) return;
            $http.get(uri + '/GetUsers')
                .success(function (data, status) {
                   
                    $scope.users = data; // show current users
                    if ($scope.customerIdSubscribed &&
                        $scope.customerIdSubscribed.length > 0 &&
                        $scope.customerIdSubscribed !== $scope.customerId) {
                        // unsubscribe to stope to get notifications for old customer
                       // hub.server.unsubscribe($scope.customerIdSubscribed);
                    }
                    // subscribe to start to get notifications for new customer
                    //hub.server.subscribe('1');
                    $scope.customerIdSubscribed = '1';
                })
                .error(function (data, status) {
                    $scope.users = [];
                    $scope.errorToSearch = errorMessage(data, status);
                })
        };
       
        
      
        $scope.postOne = function () {
           
            $http.post(uri, {
                UserId: 0,
                UserName: $scope.descToAdd
            })
                .success(function (data, status) {
                   
                    //$window.localStorage.setItem('userid', data.UserId)
                    $window.location.href = '/index.html#?userid=' + data.UserId;
                    $scope.errorToAdd = null;
                    $scope.descToAdd = null;
                })
                .error(function (data, status) {
                    $scope.errorToAdd = errorMessage(data, status);
                })
        };
        $scope.putOne = function () {
            $http.put(uri + '/' + $scope.idToUpdate, {
                UserId: $scope.idToUpdate,
                UserName: $scope.descToUpdate
            })
                .success(function (data, status) {
                    $scope.errorToUpdate = null;
                    $scope.idToUpdate = null;
                    $scope.descToUpdate = null;
                })
                .error(function (data, status) {
                    $scope.errorToUpdate = errorMessage(data, status);
                })
        };
        $scope.deleteOne = function (item) {
            $http.delete(uri + '/' + item.UserId)
                .success(function (data, status) {
                    $scope.errorToDelete = null;
                })
                .error(function (data, status) {
                    $scope.errorToDelete = errorMessage(data, status);
                })
        };
        $scope.editIt = function (item) {
            $scope.idToUpdate = item.UserId;
            $scope.descToUpdate = item.UserName;
        };
        $scope.toShow = function () { return $scope.users && $scope.users.length > 0; };

        // at initial page load
        $scope.orderProp = 'UserId';

      
      

        $scope.$on("notification", function (event, args) {
            $scope.getAllFromCustomer();
        });
    }]);
})();
