﻿using SignalRBackEnd.DataModel;
using SignalRBackEnd.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;

namespace SignalRBackEnd.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class NotificationController : ApiControllerWithHub<ChatHub>
    {
        private SignalREntities db = new SignalREntities();

        [ResponseType(typeof(DtoMessage))]
        public IHttpActionResult GetUsers() // customer id
        {
            List<DtoMessage> cUSTOMER_COMPLAINTS = (from x in db.Messages.ToList()
                                                    select new DtoMessage
                                                    {
                                                        Message=x.Message1,
                                                        Id=x.Id,
                                                        UserId = x.Userid.Value,
                                                        UserName = db.Users.FirstOrDefault(y=>y.UserId == x.Userid).UserName
                                                    }).ToList();
            if (cUSTOMER_COMPLAINTS == null)
            {
                return NotFound();
            }

            return Ok(cUSTOMER_COMPLAINTS);
        }

        // PUT: api/Complaints/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCUSTOMER_COMPLAINTS(int id, User cUSTOMER_COMPLAINTS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != cUSTOMER_COMPLAINTS.UserId)
            {
                return BadRequest();
            }

            db.Entry(cUSTOMER_COMPLAINTS).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CUSTOMER_COMPLAINTSExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            var subscribed = Hub.Clients.Group("1");
            subscribed.updateItem(cUSTOMER_COMPLAINTS);

            return StatusCode(HttpStatusCode.NoContent);
        }



        // POST: api/Complaints
        [ResponseType(typeof(DtoMessage))]
        public IHttpActionResult PostCUSTOMER_COMPLAINTS(Message message)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
           
                db.Messages.Add(message);
                db.SaveChanges();
           
            DtoMessage dtoMessage = new DtoMessage();
            dtoMessage.Id = message.Id;
            dtoMessage.Message = message.Message1;
            dtoMessage.UserName = db.Users.FirstOrDefault(y => y.UserId == message.Userid).UserName;
            dtoMessage.UserId = message.Userid.Value;
            List<DtoMessage> cUSTOMER_COMPLAINTS = (from x in db.Messages.ToList()
                                                    select new DtoMessage
                                                    {
                                                        Message = x.Message1,
                                                        Id = x.Id,
                                                        UserId = x.Userid.Value,
                                                        UserName = db.Users.FirstOrDefault(y => y.UserId == x.Userid).UserName
                                                    }).ToList();
            foreach (var group in cUSTOMER_COMPLAINTS.Select(x=>x.UserId).Distinct())
            {
                var subscribed = Hub.Clients.Group(group.ToString());
                subscribed.addItem(dtoMessage);
            }
            
            return CreatedAtRoute("DefaultApi", new { id = dtoMessage.Id }, dtoMessage);
        }

        // DELETE: api/Complaints/5
        [ResponseType(typeof(User))]
        public IHttpActionResult DeleteCUSTOMER_COMPLAINTS(int id)
        {
            User cUSTOMER_COMPLAINTS = db.Users.Find(id);
            if (cUSTOMER_COMPLAINTS == null)
            {
                return NotFound();
            }

            db.Users.Remove(cUSTOMER_COMPLAINTS);
            db.SaveChanges();

            var subscribed = Hub.Clients.Group("1");
            subscribed.deleteItem(cUSTOMER_COMPLAINTS);

            return Ok(cUSTOMER_COMPLAINTS);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CUSTOMER_COMPLAINTSExists(int id)
        {
            return db.Users.Count(e => e.UserId == id) > 0;
        }
    }

}