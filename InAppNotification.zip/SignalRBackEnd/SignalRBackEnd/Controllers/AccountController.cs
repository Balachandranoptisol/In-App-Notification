﻿using SignalRBackEnd.DataModel;
using SignalRBackEnd.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;

namespace SignalRBackEnd.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AccountController : ApiController
    {
        private SignalREntities db = new SignalREntities();
        [ResponseType(typeof(DtoUser))]
        public IHttpActionResult Post(User cUSTOMER_COMPLAINTS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (db.Users.FirstOrDefault(x => x.UserName.ToLower() == cUSTOMER_COMPLAINTS.UserName.ToLower()) == null)
            {
                db.Users.Add(cUSTOMER_COMPLAINTS);
                db.SaveChanges();
            }
            else
            {
                cUSTOMER_COMPLAINTS = db.Users.FirstOrDefault(x => x.UserName == cUSTOMER_COMPLAINTS.UserName);
            }

            DtoUser dtoUser = new DtoUser();
            dtoUser.UserId = cUSTOMER_COMPLAINTS.UserId;
            dtoUser.UserName = cUSTOMER_COMPLAINTS.UserName;
            return CreatedAtRoute("DefaultApi", new { id = dtoUser.UserId }, dtoUser);
        }
    }
}
