﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Owin;

[assembly: OwinStartup(typeof(SignalRBackEnd.Startup))]

namespace SignalRBackEnd
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();

            app.Map("/signalr", map =>
            {
                map.UseCors(CorsOptions.AllowAll);
                var hubConfiguration = new HubConfiguration { };
                map.RunSignalR(hubConfiguration);
            });

            ConfigureAuth(app);

            // Any connection or hub wire up and configuration should go here
            //string connectionString = "Endpoint=sb://revflexnotification.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=5zPcmiU/v+3HUn8OfKP27cU14+6k220K9IxXJjMKxpc=";
            //GlobalHost.DependencyResolver.UseServiceBus(connectionString, "RevFlexNotification");

            app.MapSignalR();

            WebApiConfig.Register(config);
            app.UseWebApi(config);

        }
    }
}
